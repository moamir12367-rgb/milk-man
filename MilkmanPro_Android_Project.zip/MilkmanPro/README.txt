MILKMAN PRO - ANDROID APP (notification app band hone ke baad bhi)
==================================================================

Is zip mein kya hai
- app/src/main/assets/index.html  -> aapki oppo.html (bina badlav ke)
- Android code jo reminders ko phone ke AlarmManager mein lagata hai,
  isliye app band ho (recent apps se swipe) tab bhi notification aayegi.
  Phone restart ke baad bhi alarms apne aap wapas lag jaate hain.
- Bill JPG/PDF save (Downloads folder), WhatsApp image share, Backup/Restore
  file chooser - sab wrapper mein kaam karne ke liye joda hua hai.

APK banane ke 2 tareeke
-----------------------
A) Sirf phone se (PC nahi chahiye) - GitHub Actions
   1. github.com par free account banao, naya repository banao.
   2. Is zip ko extract karo, andar ka SAARA content (".github" folder samet)
      repository mein upload karo.
   3. Repository -> Actions tab -> "Build APK" chalne do (3-5 minute).
   4. Run khulne par neeche "Artifacts" mein MilkmanPRO-apk download karo,
      zip kholo, app-debug.apk install karo.

B) PC par Android Studio
   1. Android Studio kholo -> Open -> is folder ko chuno.
   2. Gradle sync hone do -> Build -> Build APK(s).

Phone mein zaroori settings (Oppo / ColorOS)
--------------------------------------------
1. Pehli baar app kholne par "Notifications Allow" dabao.
2. Battery wale popup mein "Settings kholo" -> Allow.
3. Settings -> Apps -> Milkman PRO -> Battery usage -> "Allow background activity"
   aur "Auto launch" ON karo. (Oppo ye settings aksar band rakhta hai.)
4. Alarms tab mein "Notifications ON" rakho aur "Send Test" se check karo.

Purana data
-----------
Browser wali app ka data is APK mein apne aap nahi aata. Purani app mein
Backup/Export karo, phir APK mein Restore Data se wapas lao.

Dhyan dein
----------
- Bill image / PDF aur fonts ke liye internet chahiye (html2canvas, jsPDF CDN se
  load hote hain, jaisa pehle tha).
- App band hone par notification ka text generic hota hai (jaise "Today's milk
  entry is pending"), kyunki tab app ka data check nahi hota. App khuli ho to
  woh sirf pending customers ke naam ke saath dikhata hai.
- Ye debug-signed APK hai, apne use ke liye theek hai. Play Store ke liye alag
  release key se sign karna padega.
