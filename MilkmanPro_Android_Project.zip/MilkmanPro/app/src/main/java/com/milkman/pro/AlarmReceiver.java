package com.milkman.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        PendingResult pr = goAsync();
        try {
            String id = intent.getStringExtra("id");
            JSONObject r = ReminderScheduler.findReminder(context, id);
            if (r != null && r.optBoolean("enabled", true)) {
                ReminderScheduler.notifyNow(context, ReminderScheduler.TITLE,
                        ReminderScheduler.bodyFor(r), ReminderScheduler.codeOf(id));
            }
        } finally {
            // exact alarm ek baar chalta hai, isliye agla time turant set karo
            ReminderScheduler.scheduleAll(context);
            pr.finish();
        }
    }
}
